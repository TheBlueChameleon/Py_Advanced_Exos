# Notes

## Country Comparison Pages

Country Comparison pages are presorted lists of data from selected Factbook data fields. 
Country Comparison pages are generally given in descending order - highest to lowest - such as Population and Area. 
The two exceptions are Unemployment Rate and Inflation Rate, which are in ascending - lowest to highest - order. 

Country Comparison pages are available for the following 79 fields in seven of the ten Factbook categories.

(Source: [Guide to Country Comparisons](https://www.cia.gov/library/publications/the-world-factbook/rankorder/rankorderguide.html))

